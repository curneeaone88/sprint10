# -*- coding: utf-8 -*-
import subprocess

from odoo import models, fields, api, _
import odoo.addons.decimal_precision as dp
from datetime import datetime
from dateutil.relativedelta import relativedelta
from odoo.exceptions import UserError


class lot_barang(models.Model):
    _inherit = 'stock.picking'

    x_no_sj_internal = fields.Char(string="No SJ Internal", readonly=True)
    x_note_sjk = fields.Text(string="Note")
    x_sj_supplier = fields.Char(string="Nomor Surat Jalan Supplier")


class stock_line(models.Model):
    _inherit = 'stock.pack.operation'

    x_weight = fields.Float(string='Total Weight (Kg)')
    x_qty_total = fields.Float(string='Qty Total (Roll/Sheet)')
    x_note = fields.Char(string='Description')
    x_picking_type_id = fields.Integer(string='Picking Type')
