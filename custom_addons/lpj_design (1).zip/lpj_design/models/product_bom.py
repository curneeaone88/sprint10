# -*- coding: utf-8 -*-
from odoo import models, fields, api, _


class ProductBomLine(models.Model):
    """BOM SEDERHANA -- sengaja bukan reuse mrp.bom (sama seperti keputusan
    lpj.routing vs mrp.routing): mrp.bom bawaan penuh field yang cuma
    relevan buat alur Manufacturing Order (tipe BOM, keterkaitan Routing,
    By-product, Phantom, dst.) yang tidak kita pakai sama sekali di sini.

    Ditempel LANGSUNG ke product.template (bukan model header terpisah)
    supaya tim desain cukup isi tabel ini di form product yang sudah mereka
    buka -- tidak perlu belajar layar/konsep baru.

    Satu baris = satu bahan baku + qty yang dipakai per 1 LAYOUT (bukan lagi
    per Meter Lari/M2/Pcs terpisah -- sempat dicoba basis per-baris, tapi
    ujung-ujungnya SEMUA bahan pada satu produk memang selalu proporsional
    ke jumlah layout yang naik cetak, jadi disederhanakan jadi satu basis
    saja supaya tim desain tidak perlu mikir pilih basis per bahan).

    Jumlah layout dihitung dari Total Meter Lari OK dibagi Panjang per
    Layout produk (lihat lpj.production.ok._get_jumlah_layout()), lalu
    qty tiap bahan = qty_per_unit x jumlah layout tersebut.
    """
    _name = 'lpj.product.bom.line'
    _description = 'BOM Sederhana per Produk'
    _order = 'product_tmpl_id, sequence, id'

    product_tmpl_id = fields.Many2one(
        'product.template', string='Produk', required=True, ondelete='cascade')
    sequence = fields.Integer(string='Urutan', default=10)
    material_product_id = fields.Many2one(
        'product.product', string='Bahan Baku', required=True)
    material_uom_id = fields.Many2one(
        'product.uom', string='Satuan', related='material_product_id.uom_id',
        readonly=True,
        help="Ikut satuan stok (UoM) dari Master Product bahan baku ini -- "
             "ditampilkan supaya jelas angka 'Qty per Layout' itu dalam "
             "satuan apa tanpa perlu buka Master Product bahan bakunya "
             "satu-satu. Kalau satuannya Meter/M2, berarti kertas/bahan "
             "lembaran. Kalau Gram/Kg, berarti tinta/bahan kimia. Kalau "
             "Pcs, berarti aksesoris/hardware.")
    qty_per_unit = fields.Float(
        string='Qty per Layout', required=True, digits=(16, 4),
        help="Qty bahan ini (DALAM SATUAN/UoM Master Product bahan baku "
             "tersebut, lihat kolom Satuan) yang dipakai untuk MEMPRODUKSI "
             "1 LAYOUT. Contoh: kertas UoM Meter -> isi Panjang per Layout "
             "produk ini (karena 1 layout = 1 potongan kertas sepanjang "
             "itu); tinta UoM Gram -> isi berapa gram tinta habis mencetak "
             "1 layout. Total qty yang keluar dari stok saat OK selesai = "
             "angka ini x jumlah layout (Total Meter Lari OK / Panjang per "
             "Layout produk).")

    def _history_text(self):
        self.ensure_one()
        return u"%s: %s %s per layout" % (
            self.material_product_id.display_name or u'-',
            self.qty_per_unit, self.material_uom_id.name or u'')

    @api.model
    def create(self, vals):
        rec = super(ProductBomLine, self).create(vals)
        rec.product_tmpl_id._post_history([(_(u'BOM'), u'-', u'%s (ditambah)' % rec._history_text())])
        return rec

    @api.multi
    def write(self, vals):
        tracked = [f for f in ('material_product_id', 'qty_per_unit') if f in vals]
        before = dict((r.id, r._history_text()) for r in self) if tracked else {}
        res = super(ProductBomLine, self).write(vals)
        for r in self:
            if tracked and before.get(r.id) != r._history_text():
                r.product_tmpl_id._post_history(
                    [(_(u'BOM'), before[r.id], r._history_text())])
        return res

    @api.multi
    def unlink(self):
        for r in self:
            r.product_tmpl_id._post_history(
                [(_(u'BOM'), r._history_text(), u'(dihapus)')])
        return super(ProductBomLine, self).unlink()
